#include "syscall.h"


int main(){
    PutString("BonjourjesuisBrianLebretonetenfaitc'estunpeulongtutrouvespas?");
    Halt();
}


