#include "syscall.h"


int main(){
    char c = GetChar();
}