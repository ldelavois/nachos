#include "syscall.h"


int main(){
    char ch[15];
    GetString(ch, 15);
    PutString(ch);
}