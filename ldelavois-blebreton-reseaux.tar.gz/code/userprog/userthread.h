#ifdef CHANGED
#ifndef USERTHREAD_H
#define USERTHREAD_H
#include "copyright.h"
#include "utility.h"
#include "console.h"
#include "thread.h"



int do_ThreadCreate(int f, int arg);
void do_ThreadExit(void);

#endif  //USERTHREAD
#endif  //CHANGED